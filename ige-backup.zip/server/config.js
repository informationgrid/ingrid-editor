module.exports = {
  key: {
    headerPrefix: 'Bearer ',
    privateKey: 'dud3nufswjfn',
    tokenExpiry: 60*60
  },
  database: {
    url: 'mongodb://localhost:27017/ige'
  }
};