'use strict';

module.exports.get = function (req, res) {
  res.end();
};
