import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './statistic.component.html'
})
export class StatisticComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}
