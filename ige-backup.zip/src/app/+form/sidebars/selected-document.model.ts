export interface SelectedDocument {
  id: string;
  label: string;
  profile: string;
  editable?: boolean;
  _parent?: string;
  forceLoad?: boolean;
}
