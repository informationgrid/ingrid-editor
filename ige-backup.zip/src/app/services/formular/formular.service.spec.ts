import {FormularService} from './formular.service';
import objectContaining = jasmine.objectContaining;

describe( 'Formular', () => {
  let myFormularService: FormularService;

  beforeEach(() => {
    // myFormularService = new FormularService();
  });
  /*it( 'should load data', ( done: () => void ) => {

    myFormularService.loadData( '1' ).then(( data ) => {
      expect( data.mainInfo ).toEqual( objectContaining( { taskId: '98765' }) );
      done();
    });
  });

  it( 'should load other data, too', ( done: () => void ) => {

    myFormularService.loadData( '0' ).then(( data ) => {
      expect( data.mainInfo ).toEqual( objectContaining( { taskId: '1234567' }) );
      done();
    });
  });
*/
  xit( 'should save form data', () => {

  } );

  xit( 'should validate data', () => {

  } );

  xit( 'should show form in multiple languages', () => {

  } );


  describe( 'Text field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be possible to add a custom validation', () => {

    });

    xit( 'should be able to add an event listener', () => {

    });

  });


  describe( 'Textarea field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be possible to add a custom validation', () => {

    });

    xit( 'should be able to add an event listener', () => {

    });

  });

  describe( 'Selectbox field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be possible to add a custom validation', () => {

    });

    xit( 'should be able to add an event listener', () => {

    });

  });

  describe( 'Combobox field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be possible to add a custom validation', () => {

    });

    xit( 'should be able to add an event listener', () => {

    });

  });

  describe( 'Checkbox field', () => {

    xit( 'should be able to add an event listener', () => {

    });

  });

  describe( 'Radio button field', () => {

    xit( 'should be able to add an event listener', () => {

    });

  });

  describe( 'Table field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be possible to add a custom validation', () => {

    });

    xit( 'should be able to add an event listener', () => {

    });

  });


  describe( 'Date field', () => {

    xit( 'should be defined mandatory', () => {

    });

    xit( 'should be defined required', () => {

    });

    xit( 'should be able to set a min date', () => {

    });

    xit( 'should be able to set a max date', () => {

    });

    xit( 'should be able to set a min and max date', () => {

    });

  });



  describe( 'Detail view', () => {


  });


  describe( 'Compare view', () => {

  });


  describe( 'Validators', () => {


    xit( 'should check if any text was entered', () => {

    });

    xit( 'should check if text is a number', () => {

    });

    xit( 'should check if text is an email', () => {

    });

    xit( 'should check if table has any data', () => {

    });

    xit( 'should check if some columns of a table contain required data', () => {

    });



  });


  describe('New Document', () => {

    xit('should show a choice of possible document types when creating a new document', () => {

    });

    xit('should be able to define a rule which document types are shown depending on the parent', () => {

    });

  });

  describe('Copy & Paste', () => {

  });

  describe('Cut & Paste', () => {

  });

});


describe('User behaviours/fields', () => {

  xit('should behave...', () => {

  });

});

