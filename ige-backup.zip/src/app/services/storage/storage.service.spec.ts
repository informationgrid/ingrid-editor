import { StorageService} from './storage.service';

describe( 'Save', () => {

  xit( 'should save a document when there is no validation', () => {

  });

  xit( 'should show a validation error when a field registered to onSave-validation', () => {

  });

});

describe( 'Publish', () => {

  xit( 'should show a dialog if document really should be published', () => {

  });

  xit( 'should show a validation error when a field registered to onPublish-validation', () => {

  });

});