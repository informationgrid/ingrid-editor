export enum UpdateType {
  Copy,
  Paste,
  New,
  Update,
  Delete
}